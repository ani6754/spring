/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edufect.spring;

import com.edufect.beans.student;
import com.edufect.beans1.employee;
import com.edufect.beans2.Product;
import com.edufect.beans3.Job;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author waheguru ji
 */
@Controller
public class Controller1 {
    @RequestMapping(value="/index")
    public ModelAndView welcome(){
        ModelAndView m1=new ModelAndView("index");
        m1.addObject("nameStudent","james");
         m1.addObject("age","22");
          m1.addObject("course","java");
        return m1;
        
    }
     @RequestMapping(value="/ghj")
     public ModelAndView welcome1(){
        ModelAndView m2=new ModelAndView("welcome");
        m2.addObject("studentname","james");
         m2.addObject("facultyname","games");
          
        return m2;
     }
     @RequestMapping(value="/dummystudent")
     public ModelAndView welcome2(@ModelAttribute student st1){
        ModelAndView m2=new ModelAndView("welcome");
        st1.setName("bill smith");
        st1.setAge(22);
        st1.setCourse("spring");
        m2.addObject("stObject",st1);
        return m2;
     }
     @RequestMapping(value="/dummystudent_mark")
     public ModelAndView welcome4(@ModelAttribute student st1){
        ModelAndView m2=new ModelAndView("welcome");
        st1.setName("mark");
        st1.setAge(23);
        st1.setCourse("angular");
        m2.addObject("stObject",st1);
        return m2;
     }
     @RequestMapping(value="/employee")
     public ModelAndView welcome3 (@ModelAttribute employee emp){
         ModelAndView m=new ModelAndView("employee");
         emp.setName("bill");
         emp.setAge(22);
         emp.setMobile(123456);
         emp.setId("df@gmail.com");
         m.addObject("empObject",emp);
         return m;
     }
     @RequestMapping(value="/Job",method=RequestMethod.GET)
     public ModelAndView Job_GET(@ModelAttribute Job GETst){
         ModelAndView m1=new ModelAndView("Job");
         m1.addObject("command",GETst);
         return m1;
     }
      @RequestMapping(value="/Job",method=RequestMethod.POST)
      public ModelAndView Job_POST(@ModelAttribute Job POSTst){
          if(POSTst.isWorking()){
          ModelAndView m1=new ModelAndView("welcome_1");
          m1.addObject("stObject",POSTst);
          return m1;
          
      }
          else{
              ModelAndView m1=new ModelAndView("welcome"); 
              m1.addObject("stObject",POSTst);
              System.out.println(POSTst.getName());
              return m1;
          }
      }
      @RequestMapping(value="/workingform")
      public ModelAndView workingForm(){
        ModelAndView m1=new ModelAndView("workingform");
        return m1;
      }
       @RequestMapping(value="/Product",method=RequestMethod.GET)
     public ModelAndView Product_get(@ModelAttribute Product getpr){
         ModelAndView m1=new ModelAndView("Product");
         m1.addObject("command",getpr);
         return m1;
     }
      @RequestMapping(value="/Product",method=RequestMethod.POST)
      public ModelAndView Product_post(@ModelAttribute Product postpr){
          ModelAndView m1=new ModelAndView("welcome");
          m1.addObject("prObject",postpr);
          return m1;
      }
     }
 
          
 

